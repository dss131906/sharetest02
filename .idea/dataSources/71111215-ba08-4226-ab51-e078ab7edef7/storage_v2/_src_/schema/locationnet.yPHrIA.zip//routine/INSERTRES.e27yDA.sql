create
    definer = root@`%` procedure INSERTRES(IN userid0 bigint, IN longitude0 double(20, 10), IN latitude0 double(20, 10),
                                           IN mapid0 varchar(255), IN floor0 int, IN ptime0 datetime)
BEGIN
		DECLARE ptime_before datetime;
	DECLARE num INT DEFAULT 0;
	insert into position_history values(userid0,longitude0,latitude0,mapid0,floor0,ptime0);
	select count(*) into num from position_now where userid=userid0 limit 1;
		IF NUM=1 THEN
			SELECT PTIME INTO ptime_before FROM position_now WHERE userid=userid0;
				IF ptime_before<=ptime0 THEN
					update position_now set longitude = longitude0,latitude = latitude0,floor = floor0,mapid = mapid0,ptime = ptime0 where userid = userid0;
				END IF;
		ELSE
			insert into position_now values(userid0,longitude0,latitude0,mapid0,floor0,ptime0);
		END IF;
END;

