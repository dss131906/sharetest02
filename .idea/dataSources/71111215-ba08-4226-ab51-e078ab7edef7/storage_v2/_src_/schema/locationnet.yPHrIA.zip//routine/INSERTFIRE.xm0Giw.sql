create
    definer = root@`%` procedure INSERTFIRE(IN userid0 bigint, IN temperature0 double, IN co_density0 double,
                                            IN smoke_density0 double, IN xAcceleration0 double,
                                            IN yAcceleration0 double, IN zAcceleration0 double, IN ftime0 date)
BEGIN
		DECLARE ftime_before datetime;  
	DECLARE num INT DEFAULT 0;
  insert into firedata_history values(userid0,temperature0,co_density0,smoke_density0,xAcceleration0,yAcceleration0,zAcceleration0,ftime0); 
	select count(*) into num from firedata_now where userid=userid0 limit 1;
	if num=1 THEN
		select ftime into ftime_before from firedata_now where userid=userid0;
		if ftime0>=ftime_before then
      update firedata_now set userid=userid0,temperature=temperature0,co_density=co_density0,smoke_density=smoke_density0,xAcceleration=xAcceleration0,yAcceleration=yAcceleration0,zAcceleration=zAcceleration0,ftime = ftime0 where userid = userid0;
		end if;
	ELSE
		insert into firedata_now values(userid0,temperature0,co_density0,smoke_density0,xAcceleration0,yAcceleration0,zAcceleration0,ftime0);
	end if;

END;

